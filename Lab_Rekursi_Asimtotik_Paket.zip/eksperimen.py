from time import perf_counter
from lab_rekursi import fib_naif, fib_memo, binary_search_rek, pangkat_cepat

def ukur(fungsi, *args, ulang=3):
    total = 0.0
    for _ in range(ulang):
        mulai = perf_counter()
        fungsi(*args)
        total += (perf_counter() - mulai) * 1000
    return total / ulang

print("D1. Fibonacci (ms)")
print(f"{'n':>6} | {'fib_naif':>12} | {'fib_memo':>12}")
for n in (20, 22, 24, 26, 28, 30):
    print(f"{n:6} | {ukur(fib_naif, n):12.4f} | {ukur(fib_memo, n):12.4f}")

print("\\nD2. Pencarian (ms), target tidak ada")
print(f"{'n':>9} | {'linear':>12} | {'binary_rek':>12}")
for n in (1_000, 10_000, 100_000, 1_000_000):
    arr = list(range(n))
    target = -1
    def linear(a, x):
        for i, value in enumerate(a):
            if value == x:
                return i
        return -1
    print(f"{n:9} | {ukur(linear, arr, target):12.4f} | {ukur(binary_search_rek, arr, target):12.4f}")

print("\\nD3. Pangkat 3^n (ms)")
print(f"{'n':>6} | {'pangkat_naif':>14} | {'pangkat_cepat':>14}")
def pangkat_naif(x, n):
    hasil = 1
    for _ in range(n):
        hasil *= x
    return hasil
for n in (500, 1000, 2000, 4000, 8000):
    # Untuk hasil yang lebih stabil, ukur tiga kali. Bilangan hasil sangat besar.
    print(f"{n:6} | {ukur(pangkat_naif, 3, n, ulang=1):14.4f} | {ukur(pangkat_cepat, 3, n, ulang=3):14.4f}")
